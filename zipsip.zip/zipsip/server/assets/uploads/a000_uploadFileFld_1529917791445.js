var template = {
    customerDetails:{
        firstName:'Giri',
        lastName:'Venkat',
        timeWithFidelity:'20'
    }
}

function getFullName(){
    return template.customerDetails.firstName+' '+template.customerDetails.lastName;
}

function getRelTime(){
    return template.customerDetails.timeWithFidelity;
}