var template = {
    customerDetails:{
        firstName:'Sai Prasad',
        lastName:'Sabeson',
        timeWithFidelity:'8'
    }
}

function getFullName(){
    return template.customerDetails.firstName+' '+template.customerDetails.lastName;
}

function getRelTime(){
    return template.customerDetails.timeWithFidelity;
}