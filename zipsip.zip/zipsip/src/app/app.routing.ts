import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
import { NgModule } from '@angular/core';

import { HomeComponent } from './home/home.component';
import {AdminComponent} from './admin/admin.component';


export const AppRoutes: Routes = [
    { path: 'home/:id', component: HomeComponent },
    { path: '', component: HomeComponent }
    
];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(AppRoutes);
