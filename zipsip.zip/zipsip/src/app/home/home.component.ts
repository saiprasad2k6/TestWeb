import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { Response, Http } from "@angular/http";



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userId: String = '';
  displayVideo: Boolean = false;
  apiUrl: String = 'http://localhost:3000/api/service/hasVideo/';
  userName:String="";
  
  constructor(private route: ActivatedRoute, private http: Http) {}

  ngOnInit() {
    this.userId = this.route.snapshot.params['id'];
    this.apiUrl = this.apiUrl + '' + this.userId;
    console.log(this.userId)
    this.getUserById(this.userId);
    
    this.hasVideo();

  }
  hasVideo() {
    this.http.get(this.apiUrl.toString()).subscribe(res => {
      var data = res.json();
      this.displayVideo= data.code == 200 && data.videoName != '';
    });
  }

  public getUserById(userId){
    var url="http://localhost:3000/api/service/getUser/"+userId;
    return this.http.get(url).subscribe(res=>{
      var data=res.json();
      this.userName=data.user.userName;
      console.log(data);
    });
  }

}
