import { Component, OnInit } from '@angular/core';
import {AdminService}from '../admin.service';



@Component({
  selector: 'app-admin-render-work-job',
  templateUrl: './admin-render-work-job.component.html',
  styleUrls: ['./admin-render-work-job.component.css']
})
export class AdminRenderWorkJobComponent implements OnInit {

  constructor(private service:AdminService) { }
  
  ngOnInit() {
    
  }

  displayResults:Boolean=false;
  

  public renderWorkJob(){
    console.log('renderWorkJob');
    this.service.renderWorkJob().subscribe(response=>{
      if(response['code']==200) this.displayResults=true;

    });
  }
}
