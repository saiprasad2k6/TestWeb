import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';





@Injectable()
export class AdminService {
  constructor(protected _http: HttpClient) { }

  private  uploadFile(userId,data){
    return this._http.post('http://localhost:3000/api/service/uploadFile/'+userId,data);
  }

  private createProject(userId,data){

    return this._http.post("http://localhost:3000/api/service/createProject/"+userId,data)
  }

  public createWorkJob(userId,data){
    this.uploadFile(userId,data[0]).subscribe(response=>{
      var path=response[0].path;
      var project=data[1].project;
      project.assets[1].src=path;
      
      this.createProject(userId,data[1]).subscribe(response=>{
        console.log(JSON.stringify(response));
      });
    });
  }

  

  public renderWorkJob(){
    var url="http://localhost:3000/api/service/render";
    return this._http.get(url);
  }

  public getWorkJobs(){
    var url1=this._http.get("http://localhost:3000/api/projects/");
    var url2=this._http.get("http://localhost:3000/api/service/getUsers");
     return forkJoin([url1,url2]);
  }
}

  