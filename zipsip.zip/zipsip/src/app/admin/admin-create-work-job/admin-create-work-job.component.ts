import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {AdminService}from '../admin.service'

@Component({
  selector: 'app-admin-create-work-job',
  templateUrl: './admin-create-work-job.component.html',
  styleUrls: ['./admin-create-work-job.component.css']
})
export class AdminCreateWorkJobComponent implements OnInit {

  constructor(private http: HttpClient,private service:AdminService) { }
  form;
  fileToUpload: any;
  userId:String;
  displayResults:Boolean;
  templateName="fa-video-template-0-1.aepx";
  ngOnInit() {
    this.form = new FormGroup({
      templateName: new FormControl(this.templateName),
      userId: new FormControl(""),
      dataFile: new FormControl(""),
      fullName:new FormControl("")
    });
  }

  public uploadFileEvent($event) {
    const fileSelected: File = $event.target.files[0];
    this.fileToUpload = fileSelected;
  }

  onSubmit(user) {
    this.userId=user.userId;
    var requestCreateProject=this.preparePayloadForCreateProject();
    requestCreateProject['user']['userId']=this.userId;
    requestCreateProject['user']['userName']=user.fullName;
    this.service.createWorkJob(this.userId,[this.preparePayloadForFileUpload(),requestCreateProject]);
    this.displayResults=true;

  }


  preparePayloadForFileUpload(){
    const _formData = new FormData();
    _formData.append('fieldname', 'template-data');
    _formData.append('uploadFileFld', this.fileToUpload);
    _formData.append('userId', this.userId.toString());
    return _formData;
  }

  
  preparePayloadForCreateProject(){
    let request={};
    request['user']={userId:'',userName:''};
    request['project']={  
      "template":"fa-video-template-0-1.aepx",
      "composition":"main",
      "assets":[  
         {  
            "type":"project",
            "name":"project.aepx",
            "src":"/Users/saiprasad/Documents/Workspace/Angular/Tutorials/video-demo/server/assets/"+this.templateName
         },
         {  
            "type":"script",
            "name":"template-data.js",
            "src":"http://localhost:23234/asset/template-data.js"
         }
      ],
      "settings":{  
        'outputModule': 'Production',
        'outputExt': 'mov'

      },
      "actions":[  
   
      ],
      "state":"queued",
      "createdAt":new Date(),
      "updatedAt":new Date()
   }
   return request;
   
  };
}
