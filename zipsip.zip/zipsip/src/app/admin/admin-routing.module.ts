import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AdminComponent } from "./admin.component";
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminCreateWorkJobComponent } from './admin-create-work-job/admin-create-work-job.component';
import {AdminViewWorkJobComponent} from './admin-view-work-job/admin-view-work-job.component';
import {AdminRenderWorkJobComponent} from './admin-render-work-job/admin-render-work-job.component';

const adminRoutes: Routes = [
    {
        path:  'admin', component: AdminComponent ,
        children: [
            {path:'home',component:AdminHomeComponent},
            {path:'admin',redirectTo:'home'},
            {path: 'createProject',component: AdminCreateWorkJobComponent},
            {path: 'renderWorkJob',component: AdminRenderWorkJobComponent},
            {path: 'viewWorkJob',component: AdminViewWorkJobComponent}
        ]
    }
]


@NgModule({
    imports: [
        RouterModule.forChild(adminRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class AdminRoutingModule { }