import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {AdminService}from '../admin.service'

@Component({
  selector: 'app-admin-view-work-job',
  templateUrl: './admin-view-work-job.component.html',
  styleUrls: ['./admin-view-work-job.component.css']
})
export class AdminViewWorkJobComponent implements OnInit {

  constructor(private service:AdminService) { }
  projects:Array<any>;
  ngOnInit() {
    this.loadJobs();
  }

  loadJobs(){
    this.service.getWorkJobs().subscribe(results=>{
      let users=results[1]['users'];
      let userProjectUserIdMatrix=[];
      let userProjectUserNameMatrix=[];
      console.log(results[1]['users']);
      console.log(users);
      users.forEach(user=>{
        userProjectUserIdMatrix[user['projectId']]=user['userId'];
        userProjectUserNameMatrix[user['projectId']]=user['userName'];
      });
    
      this.projects=<Array<any>> results[0];
      this.projects.forEach(project=>{
        project['userId']=userProjectUserIdMatrix[project['uid']];
        project['userName']=userProjectUserNameMatrix[project['uid']];
      });
    })
  }
 
}
