import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';
import { ReactiveFormsModule }    from '@angular/forms';
 
import { AdminComponent }    from './admin.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminCreateWorkJobComponent } from './admin-create-work-job/admin-create-work-job.component';

import {AdminViewWorkJobComponent} from './admin-view-work-job/admin-view-work-job.component';
import {AdminRenderWorkJobComponent} from './admin-render-work-job/admin-render-work-job.component';


import {AdminService} from './admin.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';



 
import { AdminRoutingModule } from './admin-routing.module';

 
@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    HttpClientModule
  ],
  declarations: [
    AdminComponent,
    AdminHomeComponent,
    AdminCreateWorkJobComponent,
    AdminRenderWorkJobComponent,
    AdminViewWorkJobComponent

  ],
  providers: [AdminService]
})
export class AdminModule {}